import 'package:flutter/material.dart';
import 'home_page.dart'; // Untuk kelas UKM
import 'pendaftaran_ukm.dart'; // Untuk RegistrationPage (pendaftaran organisasi)

class DetailPage extends StatelessWidget {
  final UKM ukm;

  const DetailPage({Key? key, required this.ukm}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('images/polbeng_logo.png', height: 30),
            SizedBox(width: 10),
            Text(
              ukm.name,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontFamily: 'Roboto',
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xFF1E3A8A),
        elevation: 4,
      ),
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF60A5FA), Color(0xFF1E3A8A)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 40,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      child: Image.asset(ukm.logoPath, fit: BoxFit.cover),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            ukm.name,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            ukm.category,
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.info_outline,
                    color: Color(0xFF1E3A8A),
                    size: 28,
                  ),
                  title: Text(
                    'Tentang ${ukm.name}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  subtitle: Text(
                    _getAboutDescription(ukm.name),
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 16),
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.group,
                    color: Color(0xFF1E3A8A),
                    size: 28,
                  ),
                  title: Text(
                    'Divisi',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  subtitle: Text(
                    _getDivisions(ukm.name),
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 16),
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.checklist,
                    color: Color(0xFF1E3A8A),
                    size: 28,
                  ),
                  title: Text(
                    'Persyaratan Pendaftaran',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  subtitle: Text(
                    ukm.requirements,
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 16),
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.schedule,
                    color: Color(0xFF1E3A8A),
                    size: 28,
                  ),
                  title: Text(
                    'Jadwal Pertemuan',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  subtitle: Text(
                    ukm.meetingTime,
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 16),
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.contact_phone,
                    color: Color(0xFF1E3A8A),
                    size: 28,
                  ),
                  title: Text(
                    'Informasi Kontak',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  subtitle: Text(
                    ukm.contact,
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    try {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RegistrationPage(ukm: ukm),
                        ),
                      );
                    } catch (e) {
                      ScaffoldMessenger.of(
                        context,
                      ).showSnackBar(SnackBar(content: Text('Error: $e')));
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1E3A8A),
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 5,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.person_add, color: Colors.white),
                      SizedBox(width: 8),
                      Text(
                        'Daftar Sekarang',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  String _getAboutDescription(String ukmName) {
    switch (ukmName) {
      case 'HIMTI':
        return 'HIMTI adalah komunitas energi kreatif! Bergabunglah untuk mengasah skill IT dan jadi bagian dari revolusi teknologi di Polbeng.';
      case 'HIMSIS':
        return 'HIMSIS membawa inovasi sistem informasi ke level berikutnya. Siap jadi ahli teknologi bisnis masa depan?';
      case 'LDK Al-Islam':
        return 'LDK Al-Islam mengajakmu menjalani spiritualitas dengan penuh semangat dan kontribusi nyata di kampus!';
      case 'Persekutuan Kristen':
        return 'Persekutuan Kristen membuka pintu iman dan persahabatan. Bergabunglah untuk inspirasi rohani!';
      case 'Futsal Club':
        return 'Futsal Club Polbeng: Arena untuk mengekspresikan bakat olahraga dan membangun tim impian!';
      case 'Paduan Suara':
        return 'Paduan Suara Polbeng adalah panggung kejayaan vokal. Siap jadi bintang musik kampus?';
      case 'English Club':
        return 'English Club: Tempatmu menguasai bahasa global dengan cara yang seru dan dinamis!';
      default:
        return ukm.fullDescription;
    }
  }

  String _getDivisions(String ukmName) {
    switch (ukmName) {
      case 'HIMTI':
        return '• Kominfo: Master informasi digital\n• Humas: Duta komunikasi eksternal\n• Kreatif: Seni desain dan inovasi';
      case 'HIMSIS':
        return '• Pengembangan Sistem: Arsitek teknologi\n• Riset: Peneliti masa depan\n• Event: Koordinator acara cerdas';
      case 'LDK Al-Islam':
        return '• Dakwah: Penerang spiritualitas\n• Pendidikan: Guru inspirasi\n• Sosial: Pahlawan kemanusiaan';
      case 'Persekutuan Kristen':
        return '• Pelayanan: Pemimpin rohani\n• Musik: Maestro pujian\n• Konseling: Teman dukungan jiwa';
      case 'Futsal Club':
        return '• Pelatih: Strategis lapangan\n• Manajemen: Otak di balik kemenangan\n• Medis: Penjaga kesehatan';
      case 'Paduan Suara':
        return '• Vokal: Suara emas kampus\n• Musik: Dirigen harmoni\n• Produksi: Koreografer panggung';
      case 'English Club':
        return '• Pembelajaran: Guru bahasa dunia\n• Debate: Juara argumen\n• Media: Kreator konten global';
      default:
        return 'Tidak ada divisi yang tersedia';
    }
  }
}
