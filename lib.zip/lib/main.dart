import 'package:flutter/material.dart';
import 'login.dart';
import 'home_page.dart';
import 'register.dart'; // Untuk RegisterPage (pendaftaran akun)
import 'pendaftaran_ukm.dart'; // Untuk RegistrationPage (pendaftaran organisasi)

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pemilihan UKM',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: LoginPage(), // Halaman awal adalah LoginPage
      routes: {
        '/home': (context) => HomePage(), // Rute ke HomePage
        '/register': (context) => RegisterPage(), // Rute ke RegisterPage untuk registrasi akun
        // RegistrationPage akan diakses dari DetailPage, tidak perlu rute terpisah di sini
      },
      debugShowCheckedModeBanner: false,
    );
  }
}